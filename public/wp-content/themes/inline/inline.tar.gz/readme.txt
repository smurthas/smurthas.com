##### WARRANTY #####

BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

##### WARRANTY #####

##### INLINE THEME URL #####

http://inline.thomasgriffinmedia.com/

##### HOW TO INSTALL INLINE #####

1. Go to Dashboard > Appearance > Themes and click on the "Manage Themes" tab.
2. Search for "inLine" in the search area.
3. Install and activate inLine.

1. Download the inLine theme from the WordPress repository.
2. Upload the theme via FTP to you wp-content/themes folder.
3. Go to Dashoboard > Appearance > Themes and activate inLine.

##### INLINE SUPPORT #####

http://inline.thomasgriffinmedia.com/support/

